from collections.abc import Callable
from time import time
from typing import List, Set, Tuple, Optional, Dict
import hashlib

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from game import *
from game.enums import Direction, MoveType, Result
from game import board


class PositionEvaluationNet(nn.Module):
    """Neural network for evaluating board positions."""
    
    def __init__(self, map_size=8):
        super().__init__()
        # Input: board state (8x8xchannels)
        # Channels: player_pos, enemy_pos, player_eggs, enemy_eggs, player_turds, enemy_turds, trapdoor_risk
        self.conv1 = nn.Conv2d(7, 64, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(128, 64, kernel_size=3, padding=1)
        
        # Global features: eggs, turds, turns, time
        self.fc1 = nn.Linear(64 * map_size * map_size + 8, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 64)
        self.fc4 = nn.Linear(64, 1)  # Single output: position value
        
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, board_tensor, global_features):
        # Convolutional layers
        x = F.relu(self.conv1(board_tensor))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        
        # Flatten
        x = x.view(x.size(0), -1)
        
        # Concatenate with global features
        x = torch.cat([x, global_features], dim=1)
        
        # Fully connected layers
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = F.relu(self.fc3(x))
        x = self.fc4(x)
        
        return x


class MovePredictionNet(nn.Module):
    """Neural network for predicting move quality."""
    
    def __init__(self, map_size=8):
        super().__init__()
        # Input: board state + move features
        self.conv1 = nn.Conv2d(7, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        
        # Move features: direction (4), move_type (3), new_position (2)
        self.fc1 = nn.Linear(64 * map_size * map_size + 9, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)  # Move quality score
        
    def forward(self, board_tensor, move_features):
        x = F.relu(self.conv1(board_tensor))
        x = F.relu(self.conv2(x))
        x = x.view(x.size(0), -1)
        x = torch.cat([x, move_features], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x


class TrapdoorInferenceNet(nn.Module):
    """Neural network for trapdoor location inference."""
    
    def __init__(self, map_size=8):
        super().__init__()
        # Input: sensor history + current position
        # Process sequence of sensor readings
        self.lstm = nn.LSTM(input_size=6, hidden_size=64, num_layers=2, batch_first=True)
        # 6 features: position (2), sensor_hear_0, sensor_feel_0, sensor_hear_1, sensor_feel_1
        
        self.fc1 = nn.Linear(64 + 2, 128)  # LSTM output + current position
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, map_size * map_size)  # Output: probability map
        
    def forward(self, sensor_sequence, current_pos):
        lstm_out, _ = self.lstm(sensor_sequence)
        lstm_out = lstm_out[:, -1, :]  # Take last output
        x = torch.cat([lstm_out, current_pos], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x.view(-1, 8, 8)  # Reshape to map


class OpponentModelingNet(nn.Module):
    """Neural network for modeling opponent behavior."""
    
    def __init__(self):
        super().__init__()
        # Input: sequence of opponent moves
        # Each move: direction (4), move_type (3), position (2) = 9 features
        self.lstm = nn.LSTM(input_size=9, hidden_size=64, num_layers=2, batch_first=True)
        self.fc1 = nn.Linear(64, 32)
        self.fc2 = nn.Linear(32, 4)  # Output: [aggressive, defensive, corner_focused, mobility_focused]
        
    def forward(self, move_sequence):
        lstm_out, _ = self.lstm(move_sequence)
        lstm_out = lstm_out[:, -1, :]
        x = F.relu(self.fc1(lstm_out))
        x = torch.sigmoid(self.fc2(x))  # Probabilities
        return x


class PlayerAgent:
    """
    Elite neural network-enhanced agent with deep learning for evaluation,
    move prediction, trapdoor inference, and opponent modeling.
    """

    def __init__(self, board: board.Board, time_left: Callable):
        self.map_size = board.game_map.MAP_SIZE
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Initialize neural networks
        self.eval_net = PositionEvaluationNet(self.map_size).to(self.device)
        self.move_net = MovePredictionNet(self.map_size).to(self.device)
        self.trapdoor_net = TrapdoorInferenceNet(self.map_size).to(self.device)
        self.opponent_net = OpponentModelingNet().to(self.device)
        
        # Initialize networks with reasonable weights (Xavier initialization)
        for net in [self.eval_net, self.move_net, self.trapdoor_net, self.opponent_net]:
            for m in net.modules():
                if isinstance(m, (nn.Conv2d, nn.Linear)):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)
        
        # Set to evaluation mode
        self.eval_net.eval()
        self.move_net.eval()
        self.trapdoor_net.eval()
        self.opponent_net.eval()
        
        # Initialize trapdoor belief maps
        self.trapdoor_beliefs = [
            np.ones((self.map_size, self.map_size), dtype=np.float32),
            np.ones((self.map_size, self.map_size), dtype=np.float32)
        ]
        
        # Normalize initial beliefs
        for i in range(self.map_size):
            for j in range(self.map_size):
                parity = (i + j) % 2
                if parity == 0:
                    self.trapdoor_beliefs[1][i, j] = 0.0
                else:
                    self.trapdoor_beliefs[0][i, j] = 0.0
        
        for belief_map in self.trapdoor_beliefs:
            total = np.sum(belief_map)
            if total > 0:
                belief_map /= total
        
        # Track found trapdoors
        self.found_trapdoors = set()
        
        # Search parameters
        self.max_depth = 6
        self.quiescence_depth = 3
        self.time_per_move = 8.0
        
        # Transposition table with board hash -> (score, depth, flag)
        self.transposition_table: Dict[int, Tuple[float, int, int]] = {}
        self.tt_size = 100000
        
        # Opponent modeling
        self.opponent_moves_history: List[Tuple[Direction, MoveType, Tuple[int, int]]] = []
        self.sensor_history: List[Tuple[Tuple[int, int], List[Tuple[bool, bool]]]] = []
        self.opponent_style = np.array([0.5, 0.5, 0.5, 0.5])  # [aggressive, defensive, corner, mobility]
        
        # Killer moves and history heuristic
        self.killer_moves: Dict[int, List[Tuple[Direction, MoveType]]] = {}
        self.history_table: Dict[Tuple[Direction, MoveType], int] = {}
        
        # Cached trapdoor risk map (recomputed when beliefs change)
        self.cached_risk_map: Optional[np.ndarray] = None
        self.risk_map_valid = False
        
        # Neural network confidence (lower when untrained)
        self.nn_confidence = 0.3  # Start conservative, increase if nets are trained
        self.turn_count = 0  # Track turns for adaptive confidence
        
    def board_to_tensor(self, board: board.Board) -> torch.Tensor:
        """Convert board state to neural network input tensor (uses cached risk map)."""
        tensor = np.zeros((7, self.map_size, self.map_size), dtype=np.float32)
        
        my_loc = board.chicken_player.get_location()
        enemy_loc = board.chicken_enemy.get_location()
        
        # Channel 0: Player position
        if 0 <= my_loc[0] < self.map_size and 0 <= my_loc[1] < self.map_size:
            tensor[0, my_loc[0], my_loc[1]] = 1.0
        
        # Channel 1: Enemy position
        if 0 <= enemy_loc[0] < self.map_size and 0 <= enemy_loc[1] < self.map_size:
            tensor[1, enemy_loc[0], enemy_loc[1]] = 1.0
        
        # Channel 2: Player eggs
        for egg in board.eggs_player:
            if 0 <= egg[0] < self.map_size and 0 <= egg[1] < self.map_size:
                tensor[2, egg[0], egg[1]] = 1.0
        
        # Channel 3: Enemy eggs
        for egg in board.eggs_enemy:
            if 0 <= egg[0] < self.map_size and 0 <= egg[1] < self.map_size:
                tensor[3, egg[0], egg[1]] = 1.0
        
        # Channel 4: Player turds
        for turd in board.turds_player:
            if 0 <= turd[0] < self.map_size and 0 <= turd[1] < self.map_size:
                tensor[4, turd[0], turd[1]] = 1.0
        
        # Channel 5: Enemy turds
        for turd in board.turds_enemy:
            if 0 <= turd[0] < self.map_size and 0 <= turd[1] < self.map_size:
                tensor[5, turd[0], turd[1]] = 1.0
        
        # Channel 6: Trapdoor risk (use cached map)
        if not self.risk_map_valid:
            self.compute_risk_map()
        tensor[6] = self.cached_risk_map
        
        return torch.from_numpy(tensor).unsqueeze(0).to(self.device)
    
    def get_global_features(self, board: board.Board) -> torch.Tensor:
        """Extract global features for neural network."""
        features = np.array([
            board.chicken_player.get_eggs_laid(),
            board.chicken_enemy.get_eggs_laid(),
            board.chicken_player.get_turds_left(),
            board.chicken_enemy.get_turds_left(),
            board.turns_left_player / board.MAX_TURNS,
            board.turns_left_enemy / board.MAX_TURNS,
            board.player_time / board.time_to_play,
            board.enemy_time / board.time_to_play,
        ], dtype=np.float32)
        return torch.from_numpy(features).unsqueeze(0).to(self.device)
    
    def heuristic_evaluate_position(self, board: board.Board) -> float:
        """Heuristic evaluation (fallback when NN is untrained)."""
        my_eggs = board.chicken_player.get_eggs_laid()
        enemy_eggs = board.chicken_enemy.get_eggs_laid()
        score = my_eggs - enemy_eggs
        
        if board.is_game_over():
            winner = board.get_winner()
            if winner == Result.PLAYER:
                return 1000.0
            elif winner == Result.ENEMY:
                return -1000.0
            else:
                return 0.0
        
        my_moves = len(board.get_valid_moves())
        enemy_moves = len(board.get_valid_moves(enemy=True))
        score += (my_moves - enemy_moves) * 0.1
        
        if enemy_moves == 0 and board.turns_left_enemy > 0:
            score += 5.0
        
        my_loc = board.chicken_player.get_location()
        if (my_loc[0] == 0 or my_loc[0] == self.map_size - 1) and \
           (my_loc[1] == 0 or my_loc[1] == self.map_size - 1) and \
           board.can_lay_egg_at_loc(my_loc):
            score += 2.0
        
        risk = self.get_trapdoor_risk(my_loc)
        score -= risk * 4.0
        
        return score
    
    def neural_evaluate_position(self, board: board.Board) -> float:
        """Use neural network to evaluate position (with fallback to heuristics)."""
        # Check for terminal conditions first
        if board.is_game_over():
            winner = board.get_winner()
            if winner == Result.PLAYER:
                return 1000.0
            elif winner == Result.ENEMY:
                return -1000.0
            else:
                return 0.0
        
        # Get heuristic evaluation
        heuristic_score = self.heuristic_evaluate_position(board)
        
        # If NN confidence is low, use mostly heuristics
        if self.nn_confidence < 0.5:
            return heuristic_score
        
        # Use neural network with confidence weighting
        try:
            with torch.no_grad():
                board_tensor = self.board_to_tensor(board)
                global_features = self.get_global_features(board)
                nn_value = self.eval_net(board_tensor, global_features).item()
                
                # Blend: more weight on heuristics when NN is untrained
                final_value = nn_value * self.nn_confidence + heuristic_score * (1 - self.nn_confidence)
                return final_value
        except Exception:
            # Fallback to heuristics on error
            return heuristic_score
    
    def update_trapdoor_beliefs_neural(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        location: Tuple[int, int]
    ):
        """Update trapdoor beliefs using neural network + Bayesian inference."""
        # Add to sensor history
        self.sensor_history.append((location, sensor_data))
        
        # Keep only recent history (last 10 turns)
        if len(self.sensor_history) > 10:
            self.sensor_history.pop(0)
        
        # Use neural network if we have enough history
        if len(self.sensor_history) >= 3:
            with torch.no_grad():
                # Prepare sensor sequence
                sensor_seq = []
                for loc, sensors in self.sensor_history:
                    sensor_seq.append([
                        float(loc[0]) / self.map_size,
                        float(loc[1]) / self.map_size,
                        float(sensors[0][0]),
                        float(sensors[0][1]),
                        float(sensors[1][0]),
                        float(sensors[1][1]),
                    ])
                
                sensor_tensor = torch.tensor([sensor_seq], dtype=torch.float32).to(self.device)
                current_pos_tensor = torch.tensor([[location[0] / self.map_size, location[1] / self.map_size]], 
                                                 dtype=torch.float32).to(self.device)
                
                # Get neural network prediction
                nn_prediction = self.trapdoor_net(sensor_tensor, current_pos_tensor)
                nn_prediction = F.softmax(nn_prediction.view(-1), dim=0).cpu().numpy()
                nn_prediction = nn_prediction.reshape(self.map_size, self.map_size)
                
                # Blend with Bayesian update
                chicken = board.chicken_player
                for trapdoor_idx in range(2):
                    did_hear, did_feel = sensor_data[trapdoor_idx]
                    
                    for i in range(self.map_size):
                        for j in range(self.map_size):
                            parity = (i + j) % 2
                            if (trapdoor_idx == 0 and parity != 0) or (trapdoor_idx == 1 and parity != 1):
                                continue
                            
                            hear_prob, feel_prob = chicken.prob_senses_if_trapdoor_were_at(
                                did_hear, did_feel, i, j
                            )
                            likelihood = hear_prob * feel_prob
                            
                            # Blend neural network prediction (30%) with Bayesian update (70%)
                            self.trapdoor_beliefs[trapdoor_idx][i, j] *= likelihood
                            self.trapdoor_beliefs[trapdoor_idx][i, j] = (
                                0.7 * self.trapdoor_beliefs[trapdoor_idx][i, j] +
                                0.3 * nn_prediction[i, j]
                            )
                    
                    # Normalize
                    total = np.sum(self.trapdoor_beliefs[trapdoor_idx])
                    if total > 0:
                        self.trapdoor_beliefs[trapdoor_idx] /= total
        else:
            # Use pure Bayesian update for early game
            chicken = board.chicken_player
            for trapdoor_idx in range(2):
                did_hear, did_feel = sensor_data[trapdoor_idx]
                
                for i in range(self.map_size):
                    for j in range(self.map_size):
                        parity = (i + j) % 2
                        if (trapdoor_idx == 0 and parity != 0) or (trapdoor_idx == 1 and parity != 1):
                            continue
                        
                        hear_prob, feel_prob = chicken.prob_senses_if_trapdoor_were_at(
                            did_hear, did_feel, i, j
                        )
                        likelihood = hear_prob * feel_prob
                        self.trapdoor_beliefs[trapdoor_idx][i, j] *= likelihood
                
                total = np.sum(self.trapdoor_beliefs[trapdoor_idx])
                if total > 0:
                    self.trapdoor_beliefs[trapdoor_idx] /= total
        
        # Invalidate risk map cache
        self.risk_map_valid = False
    
    def compute_risk_map(self):
        """Compute and cache the full trapdoor risk map."""
        if self.risk_map_valid and self.cached_risk_map is not None:
            return
        
        risk_map = np.zeros((self.map_size, self.map_size), dtype=np.float32)
        for i in range(self.map_size):
            for j in range(self.map_size):
                if (i, j) in self.found_trapdoors:
                    risk_map[i, j] = 0.0
                else:
                    risk_map[i, j] = self.trapdoor_beliefs[0][i, j] + self.trapdoor_beliefs[1][i, j]
        
        self.cached_risk_map = risk_map
        self.risk_map_valid = True
    
    def get_trapdoor_risk(self, location: Tuple[int, int]) -> float:
        """Get combined risk of stepping on a trapdoor (uses cached map)."""
        if location in self.found_trapdoors:
            return 0.0
        
        if not self.risk_map_valid:
            self.compute_risk_map()
        
        x, y = location
        if 0 <= x < self.map_size and 0 <= y < self.map_size:
            return self.cached_risk_map[x, y]
        return 0.0
    
    def update_opponent_model(self, opponent_move: Tuple[Direction, MoveType], position: Tuple[int, int]):
        """Update opponent model using neural network."""
        self.opponent_moves_history.append((opponent_move[0], opponent_move[1], position))
        
        # Keep only recent history
        if len(self.opponent_moves_history) > 20:
            self.opponent_moves_history.pop(0)
        
        if len(self.opponent_moves_history) >= 3 and self.nn_confidence >= 0.5:
            try:
                with torch.no_grad():
                    # Prepare move sequence (safe enum indexing)
                    move_seq = []
                    for dir, move_type, pos in self.opponent_moves_history:
                        move_features = np.zeros(9, dtype=np.float32)
                        # Safe enum indexing - use actual enum values
                        dir_val = dir.value if hasattr(dir, 'value') else int(dir)
                        move_type_val = move_type.value if hasattr(move_type, 'value') else int(move_type)
                        if 0 <= dir_val < 4:
                            move_features[dir_val] = 1.0
                        if 0 <= move_type_val < 3:
                            move_features[4 + move_type_val] = 1.0
                        move_features[7] = pos[0] / self.map_size
                        move_features[8] = pos[1] / self.map_size
                        move_seq.append(move_features)
                    
                    move_tensor = torch.tensor([move_seq], dtype=torch.float32).to(self.device)
                    style_prediction = self.opponent_net(move_tensor).cpu().numpy()[0]
                    self.opponent_style = 0.7 * self.opponent_style + 0.3 * style_prediction
            except Exception:
                pass  # Fallback: keep current style estimate
    
    def neural_order_moves(self, board: board.Board, moves: List[Tuple[Direction, MoveType]]) -> List[Tuple[Direction, MoveType]]:
        """Order moves using neural network prediction."""
        if not moves:
            return moves
        
        my_loc = board.chicken_player.get_location()
        board_tensor = self.board_to_tensor(board)
        
        move_scores = []
        
        with torch.no_grad():
            for move in moves:
                dir, move_type = move
                new_loc = board.chicken_player.get_next_loc(dir, my_loc)
                
                if new_loc is None:
                    move_scores.append((float('-inf'), move))
                    continue
                
                # Prepare move features (safe enum indexing)
                move_features = np.zeros(9, dtype=np.float32)
                dir_val = dir.value if hasattr(dir, 'value') else int(dir)
                move_type_val = move_type.value if hasattr(move_type, 'value') else int(move_type)
                if 0 <= dir_val < 4:
                    move_features[dir_val] = 1.0
                if 0 <= move_type_val < 3:
                    move_features[4 + move_type_val] = 1.0
                move_features[7] = new_loc[0] / self.map_size
                move_features[8] = new_loc[1] / self.map_size
                move_features_tensor = torch.from_numpy(move_features).unsqueeze(0).to(self.device)
                
                # Get neural network prediction (with fallback)
                if self.nn_confidence >= 0.5:
                    try:
                        move_score = self.move_net(board_tensor, move_features_tensor).item()
                    except Exception:
                        move_score = 0.0
                else:
                    move_score = 0.0
                
                # Add heuristic bonuses
                if move_type == MoveType.EGG:
                    move_score += 5.0
                    if (new_loc[0] == 0 or new_loc[0] == self.map_size - 1) and \
                       (new_loc[1] == 0 or new_loc[1] == self.map_size - 1):
                        move_score += 3.0  # Corner bonus
                
                # Avoid trapdoors
                risk = self.get_trapdoor_risk(new_loc)
                move_score -= risk * 10.0
                
                # History heuristic
                if move in self.history_table:
                    move_score += self.history_table[move] * 0.1
                
                move_scores.append((move_score, move))
        
        # Sort by score
        move_scores.sort(key=lambda x: x[0], reverse=True)
        return [move for _, move in move_scores]
    
    def board_hash(self, board: board.Board) -> int:
        """Generate hash for transposition table."""
        # Simple hash based on key board features
        h = hash((
            board.chicken_player.get_location(),
            board.chicken_enemy.get_location(),
            tuple(sorted(board.eggs_player)),
            tuple(sorted(board.eggs_enemy)),
            tuple(sorted(board.turds_player)),
            tuple(sorted(board.turds_enemy)),
            board.chicken_player.get_eggs_laid(),
            board.chicken_enemy.get_eggs_laid(),
            board.turn_count
        ))
        return h % self.tt_size
    
    def minimax(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        maximizing: bool,
        start_time: float,
        time_limit: float
    ) -> float:
        """Minimax with alpha-beta pruning, transposition table, and neural network evaluation."""
        if time() - start_time > time_limit:
            return self.neural_evaluate_position(board)
        
        if board.is_game_over():
            return self.neural_evaluate_position(board)
        
        # Check transposition table
        board_hash = self.board_hash(board)
        if board_hash in self.transposition_table:
            tt_score, tt_depth, tt_flag = self.transposition_table[board_hash]
            if tt_depth >= depth:
                if tt_flag == 0:  # Exact
                    return tt_score
                elif tt_flag == 1 and tt_score >= beta:  # Lower bound
                    return tt_score
                elif tt_flag == 2 and tt_score <= alpha:  # Upper bound
                    return tt_score
        
        # Quiescence search when depth reaches 0
        if depth == 0:
            return self.quiescence_search(board, self.quiescence_depth, alpha, beta, maximizing, start_time, time_limit)
        
        if maximizing:
            max_eval = float('-inf')
            all_moves = board.get_valid_moves()
            
            # Order moves: killer moves first, then history, then neural network
            killer_moves_at_depth = self.killer_moves.get(depth, [])
            history_scores = {move: self.history_table.get(move, 0) for move in all_moves}
            
            # Separate moves into categories
            killer_list = [m for m in killer_moves_at_depth if m in all_moves]
            history_list = sorted([m for m in all_moves if m not in killer_list], 
                                key=lambda m: history_scores[m], reverse=True)
            other_moves = [m for m in all_moves if m not in killer_list and m not in history_list]
            
            # Order remaining moves with neural network
            if other_moves:
                ordered_other = self.neural_order_moves(board, other_moves)
            else:
                ordered_other = []
            
            # Combine: killers -> history -> neural ordered
            moves = killer_list + history_list[:5] + ordered_other
            
            best_move = None
            for move in moves:
                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue
                
                eval_score = self.minimax(new_board, depth - 1, alpha, beta, False, start_time, time_limit)
                max_eval = max(max_eval, eval_score)
                alpha = max(alpha, eval_score)
                best_move = move
                
                # Update history heuristic
                self.history_table[move] = self.history_table.get(move, 0) + depth * depth
                
                if beta <= alpha:
                    # Killer move
                    if depth not in self.killer_moves:
                        self.killer_moves[depth] = []
                    if move not in self.killer_moves[depth]:
                        self.killer_moves[depth].insert(0, move)
                        if len(self.killer_moves[depth]) > 2:
                            self.killer_moves[depth].pop()
                    break
                
                if time() - start_time > time_limit:
                    break
            
            # Store in transposition table
            tt_flag = 0 if max_eval > alpha and max_eval < beta else (1 if max_eval >= beta else 2)
            self.transposition_table[board_hash] = (max_eval, depth, tt_flag)
            if len(self.transposition_table) > self.tt_size:
                # Clear oldest entries (simple FIFO)
                keys_to_remove = list(self.transposition_table.keys())[:self.tt_size // 2]
                for k in keys_to_remove:
                    del self.transposition_table[k]
            
            return max_eval
        else:
            min_eval = float('inf')
            moves = board.get_valid_moves(enemy=True)
            
            for move in moves:
                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue
                
                eval_score = self.minimax(new_board, depth - 1, alpha, beta, True, start_time, time_limit)
                min_eval = min(min_eval, eval_score)
                beta = min(beta, eval_score)
                
                if beta <= alpha:
                    break
                
                if time() - start_time > time_limit:
                    break
            
            # Store in transposition table
            tt_flag = 0 if min_eval > alpha and min_eval < beta else (1 if min_eval >= beta else 2)
            self.transposition_table[board_hash] = (min_eval, depth, tt_flag)
            if len(self.transposition_table) > self.tt_size:
                keys_to_remove = list(self.transposition_table.keys())[:self.tt_size // 2]
                for k in keys_to_remove:
                    del self.transposition_table[k]
            
            return min_eval
    
    def quiescence_search(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        maximizing: bool,
        start_time: float,
        time_limit: float
    ) -> float:
        """Quiescence search for quiet positions."""
        stand_pat = self.neural_evaluate_position(board)
        
        if depth == 0:
            return stand_pat
        
        if maximizing:
            if stand_pat >= beta:
                return beta
            alpha = max(alpha, stand_pat)
        else:
            if stand_pat <= alpha:
                return alpha
            beta = min(beta, stand_pat)
        
        # Only search "tactical" moves (egg laying, blocking moves)
        moves = board.get_valid_moves() if maximizing else board.get_valid_moves(enemy=True)
        tactical_moves = [m for m in moves if m[1] != MoveType.PLAIN]
        
        if not tactical_moves:
            return stand_pat
        
        for move in tactical_moves[:5]:  # Limit to top 5 tactical moves
            dir, move_type = move
            new_board = board.forecast_move(dir, move_type, check_ok=False)
            if new_board is None:
                continue
            
            score = self.quiescence_search(new_board, depth - 1, alpha, beta, not maximizing, start_time, time_limit)
            
            if maximizing:
                alpha = max(alpha, score)
                if beta <= alpha:
                    break
            else:
                beta = min(beta, score)
                if beta <= alpha:
                    break
        
        return alpha if maximizing else beta

    def play(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        time_left: Callable,
    ) -> Tuple[Direction, MoveType]:
        """Main play function with neural network enhancements."""
        start_time = time()
        location = board.chicken_player.get_location()
        self.turn_count += 1
        
        # Update found trapdoors from board (game engine tracks these)
        self.found_trapdoors = board.found_trapdoors.copy()
        
        # Detect if we just hit a trapdoor (location reset to spawn)
        # We need to track where we were trying to move TO, not where we were
        if hasattr(self, '_last_move_dest'):
            if location == board.chicken_player.get_spawn() and self._last_move_dest != location:
                # We were reset - hit a trapdoor at the destination we tried to move to
                trapdoor_loc = self._last_move_dest
                if trapdoor_loc not in self.found_trapdoors:
                    self.found_trapdoors.add(trapdoor_loc)
                    # Set probability to 0 for this location in both belief maps
                    x, y = trapdoor_loc
                    if 0 <= x < self.map_size and 0 <= y < self.map_size:
                        self.trapdoor_beliefs[0][x, y] = 0.0
                        self.trapdoor_beliefs[1][x, y] = 0.0
                        # Renormalize
                        for belief_map in self.trapdoor_beliefs:
                            total = np.sum(belief_map)
                            if total > 0:
                                belief_map /= total
                        self.risk_map_valid = False
                        print(f"[Yolanda]: Detected trapdoor at {trapdoor_loc}, avoiding!")
        
        # Store current position for next turn
        self._last_my_pos = location
        
        # Update trapdoor beliefs with neural network
        self.update_trapdoor_beliefs_neural(board, sensor_data, location)
        
        # Gradually increase NN confidence as we play (simulates learning)
        # In practice, this would come from training, but we adapt over time
        if self.turn_count > 10:
            self.nn_confidence = min(0.7, 0.3 + (self.turn_count - 10) * 0.02)
        
        # Infer opponent's last move from board state changes
        # (We can't directly see opponent moves, but we can infer from position changes)
        if hasattr(self, '_last_enemy_pos'):
            last_enemy_pos = self._last_enemy_pos
            current_enemy_pos = board.chicken_enemy.get_location()
            if last_enemy_pos != current_enemy_pos:
                # Opponent moved - try to infer the move (approximate)
                # This is imperfect but better than nothing
                try:
                    # Find direction of movement
                    dx = current_enemy_pos[0] - last_enemy_pos[0]
                    dy = current_enemy_pos[1] - last_enemy_pos[1]
                    if abs(dx) + abs(dy) == 1:  # Valid move
                        if dx == 1:
                            inferred_dir = Direction.RIGHT
                        elif dx == -1:
                            inferred_dir = Direction.LEFT
                        elif dy == 1:
                            inferred_dir = Direction.DOWN
                        else:
                            inferred_dir = Direction.UP
                        
                        # Check if egg/turd was laid (heuristic)
                        inferred_move_type = MoveType.PLAIN
                        if current_enemy_pos in board.eggs_enemy and current_enemy_pos not in getattr(self, '_last_enemy_eggs', set()):
                            inferred_move_type = MoveType.EGG
                        elif current_enemy_pos in board.turds_enemy and current_enemy_pos not in getattr(self, '_last_enemy_turds', set()):
                            inferred_move_type = MoveType.TURD
                        
                        self.update_opponent_model((inferred_dir, inferred_move_type), current_enemy_pos)
                except Exception:
                    pass  # Ignore inference errors
        
        # Store current state for next turn
        self._last_enemy_pos = board.chicken_enemy.get_location()
        self._last_enemy_eggs = board.eggs_enemy.copy()
        self._last_enemy_turds = board.turds_enemy.copy()
        
        # Get valid moves
        moves = board.get_valid_moves()
        if not moves:
            return (Direction.UP, MoveType.PLAIN)
        
        # Time management
        remaining_time = time_left()
        remaining_turns = board.turns_left_player
        
        if remaining_turns > 0:
            time_per_move = max(1.0, remaining_time / (remaining_turns + 1))
        else:
            time_per_move = remaining_time * 0.9
        
        time_limit = min(time_per_move, remaining_time * 0.95)
        
        # Iterative deepening with neural network
        best_move = moves[0]
        best_score = float('-inf')
        achieved_depth = 0
        
        for depth in range(1, self.max_depth + 1):
            if time() - start_time > time_limit * 0.8:
                break
            
            current_best = None
            current_best_score = float('-inf')
            
            ordered_moves = self.neural_order_moves(board, moves)
            
            for move in ordered_moves:
                if time() - start_time > time_limit:
                    break
                
                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue
                
                score = self.minimax(
                    new_board,
                    depth - 1,
                    float('-inf'),
                    float('inf'),
                    False,
                    start_time,
                    time_limit - (time() - start_time)
                )
                
                if score > current_best_score:
                    current_best_score = score
                    current_best = move
            
            if current_best is not None:
                best_move = current_best
                best_score = current_best_score
                achieved_depth = depth
            
            if current_best_score > 500:
                break
        
        elapsed = time() - start_time
        print(f"NN Move: {best_move}, Score: {best_score:.2f}, Depth: {achieved_depth}, Time: {elapsed:.2f}s")
        
        # Store the destination of this move for trapdoor detection
        dir, move_type = best_move
        move_dest = board.chicken_player.get_next_loc(dir, location)
        if move_dest:
            self._last_move_dest = move_dest
        else:
            self._last_move_dest = location
        
        return best_move
