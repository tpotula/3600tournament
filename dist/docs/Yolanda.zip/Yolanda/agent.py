from collections.abc import Callable
from time import time
from typing import Dict, List, Optional, Tuple

import numpy as np
from game import board
from game.enums import Direction, MoveType, Result


class PlayerAgent:
    """
    Deterministic, heuristic-driven agent.
    Neural nets removed (no training data); focuses on fast search + clear heuristics.
    """

    def __init__(self, board: board.Board, time_left: Callable):
        self.map_size = board.game_map.MAP_SIZE

        # Trapdoor belief maps (two parities)
        self.trapdoor_beliefs = [
            np.ones((self.map_size, self.map_size), dtype=np.float32),
            np.ones((self.map_size, self.map_size), dtype=np.float32),
        ]
        for i in range(self.map_size):
            for j in range(self.map_size):
                parity = (i + j) % 2
                if parity == 0:
                    self.trapdoor_beliefs[1][i, j] = 0.0
                else:
                    self.trapdoor_beliefs[0][i, j] = 0.0
        for belief_map in self.trapdoor_beliefs:
            total = np.sum(belief_map)
            if total > 0:
                belief_map /= total

        self.found_trapdoors = set()
        self._risk_cache: Optional[np.ndarray] = None

        # Search parameters
        self.max_depth = 5
        self.quiescence_depth = 2

        # Transposition table: key -> (depth, value, flag, alpha, beta)
        self.transposition_table: Dict[Tuple, Tuple[int, float, str, float, float]] = {}
        self.tt_size = 50000

        # Ordering helpers
        self.killer_moves: Dict[int, List[Tuple[Direction, MoveType]]] = {}
        self.history_table: Dict[Tuple[Direction, MoveType], int] = {}

    def update_trapdoor_beliefs(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        location: Tuple[int, int],
    ):
        """Pure Bayesian update for trapdoor beliefs."""
        chicken = board.chicken_player
        for trapdoor_idx in range(2):
            did_hear, did_feel = sensor_data[trapdoor_idx]
            for i in range(self.map_size):
                for j in range(self.map_size):
                    parity = (i + j) % 2
                    if (trapdoor_idx == 0 and parity != 0) or (trapdoor_idx == 1 and parity != 1):
                        continue
                    hear_prob, feel_prob = chicken.prob_senses_if_trapdoor_were_at(
                        did_hear, did_feel, i, j
                    )
                    self.trapdoor_beliefs[trapdoor_idx][i, j] *= hear_prob * feel_prob
            total = np.sum(self.trapdoor_beliefs[trapdoor_idx])
            if total > 0:
                self.trapdoor_beliefs[trapdoor_idx] /= total

        self._risk_cache = None

    def get_trapdoor_risk(self, location: Tuple[int, int]) -> float:
        """Get combined risk of stepping on a trapdoor with caching."""
        if location in self.found_trapdoors:
            return 0.0
        if self._risk_cache is None:
            self._risk_cache = self.trapdoor_beliefs[0] + self.trapdoor_beliefs[1]
        x, y = location
        if 0 <= x < self.map_size and 0 <= y < self.map_size:
            return float(self._risk_cache[x, y])
        return 0.0

    def order_moves(
        self, board: board.Board, moves: List[Tuple[Direction, MoveType]], depth: int
    ) -> List[Tuple[Direction, MoveType]]:
        """Heuristic move ordering (eggs > turds > safe plains; history/killer bonuses)."""
        my_loc = board.chicken_player.get_location()
        scored = []
        for move in moves:
            dir, move_type = move
            new_loc = board.chicken_player.get_next_loc(dir, my_loc)
            if new_loc is None:
                scored.append((float("-inf"), move))
                continue

            score = 0.0

            if move_type == MoveType.EGG:
                score += 10.0
                if (new_loc[0] in (0, self.map_size - 1)) and (new_loc[1] in (0, self.map_size - 1)):
                    score += 2.0
            elif move_type == MoveType.TURD:
                score += 4.0

            # Prefer low-risk tiles
            score -= self.get_trapdoor_risk(new_loc) * 15.0

            # Encourage proximity to enemy eggs to threaten them
            nearest_enemy_egg = min(
                (abs(new_loc[0] - e[0]) + abs(new_loc[1] - e[1]) for e in board.eggs_enemy),
                default=3,
            )
            score += max(0, 3 - nearest_enemy_egg)

            score += self.history_table.get(move, 0) * 0.05
            if depth in self.killer_moves and move in self.killer_moves[depth]:
                score += 5.0

            scored.append((score, move))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored]

    def _board_hash(self, board: board.Board, maximizing: bool) -> Tuple:
        """Hashable signature for the transposition table."""
        return (
            board.chicken_player.get_location(),
            board.chicken_enemy.get_location(),
            tuple(sorted(board.eggs_player)),
            tuple(sorted(board.eggs_enemy)),
            tuple(sorted(board.turds_player)),
            tuple(sorted(board.turds_enemy)),
            board.turns_left_player,
            board.turns_left_enemy,
            maximizing,
        )

    def evaluate_position(self, board: board.Board) -> float:
        """Deterministic evaluation combining material, mobility, and risk."""
        if board.is_game_over():
            winner = board.get_winner()
            if winner == Result.PLAYER:
                return 10_000.0
            if winner == Result.ENEMY:
                return -10_000.0
            return 0.0

        my_eggs = board.chicken_player.get_eggs_laid()
        enemy_eggs = board.chicken_enemy.get_eggs_laid()
        egg_diff = my_eggs - enemy_eggs

        my_turds = board.chicken_player.get_turds_left()
        enemy_turds = board.chicken_enemy.get_turds_left()

        my_moves = len(board.get_valid_moves())
        enemy_moves = len(board.get_valid_moves(enemy=True))
        mobility = my_moves - enemy_moves

        risk_penalty = self.get_trapdoor_risk(board.chicken_player.get_location()) * 8.0

        score = (
            egg_diff * 50.0
            + mobility * 2.0
            + (my_turds - enemy_turds) * 1.0
        )
        score -= risk_penalty

        if egg_diff < 0:
            score += mobility * 2.0

        if enemy_moves == 0 and board.turns_left_enemy > 0:
            score += 100.0

        return score

    def minimax(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        maximizing: bool,
        start_time: float,
        time_limit: float,
    ) -> float:
        """Minimax with alpha-beta, quiescence, and TT."""
        orig_alpha, orig_beta = alpha, beta
        if time() - start_time > time_limit:
            return self.evaluate_position(board)

        tt_key = self._board_hash(board, maximizing)
        if tt_key in self.transposition_table:
            tt_depth, tt_value, tt_flag, tt_alpha, tt_beta = self.transposition_table[tt_key]
            if tt_depth >= depth:
                if tt_flag == "EXACT":
                    return tt_value
                if tt_flag == "LOWER":
                    alpha = max(alpha, tt_value)
                elif tt_flag == "UPPER":
                    beta = min(beta, tt_value)
                if alpha >= beta:
                    return tt_value

        if depth == 0 or board.is_game_over():
            return self.quiescence_search(
                board, self.quiescence_depth, alpha, beta, maximizing, start_time, time_limit
            )

        if maximizing:
            best = float("-inf")
            moves = self.order_moves(board, board.get_valid_moves(), depth)
            for move in moves:
                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue

                eval_score = self.minimax(new_board, depth - 1, alpha, beta, False, start_time, time_limit)
                if eval_score > best:
                    best = eval_score
                if eval_score > alpha:
                    alpha = eval_score
                self.history_table[move] = self.history_table.get(move, 0) + depth * depth

                if beta <= alpha:
                    self.killer_moves.setdefault(depth, [])
                    if move not in self.killer_moves[depth]:
                        self.killer_moves[depth].append(move)
                    break

                if time() - start_time > time_limit:
                    break
        else:
            best = float("inf")
            moves = board.get_valid_moves(enemy=True)
            for move in moves:
                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue

                eval_score = self.minimax(new_board, depth - 1, alpha, beta, True, start_time, time_limit)
                if eval_score < best:
                    best = eval_score
                if eval_score < beta:
                    beta = eval_score

                if beta <= alpha:
                    break

                if time() - start_time > time_limit:
                    break

        tt_flag = "EXACT"
        if best <= orig_alpha:
            tt_flag = "UPPER"
        elif best >= orig_beta:
            tt_flag = "LOWER"
        if len(self.transposition_table) >= self.tt_size:
            # Simple eviction to avoid unbounded growth
            self.transposition_table.pop(next(iter(self.transposition_table)))
        self.transposition_table[tt_key] = (depth, best, tt_flag, orig_alpha, orig_beta)

        return best

    def quiescence_search(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        maximizing: bool,
        start_time: float,
        time_limit: float,
    ) -> float:
        """Quiescence search for tactical stability."""
        stand_pat = self.evaluate_position(board)

        if depth == 0 or time() - start_time > time_limit:
            return stand_pat

        if maximizing:
            if stand_pat >= beta:
                return beta
            alpha = max(alpha, stand_pat)
        else:
            if stand_pat <= alpha:
                return alpha
            beta = min(beta, stand_pat)

        moves = board.get_valid_moves() if maximizing else board.get_valid_moves(enemy=True)
        tactical_moves = [m for m in moves if m[1] != MoveType.PLAIN]
        if not tactical_moves:
            return stand_pat

        for move in tactical_moves[:5]:
            dir, move_type = move
            new_board = board.forecast_move(dir, move_type, check_ok=False)
            if new_board is None:
                continue

            score = self.quiescence_search(
                new_board, depth - 1, alpha, beta, not maximizing, start_time, time_limit
            )

            if maximizing:
                alpha = max(alpha, score)
                if alpha >= beta:
                    break
            else:
                beta = min(beta, score)
                if beta <= alpha:
                    break

        return alpha if maximizing else beta

    def play(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        time_left: Callable,
    ) -> Tuple[Direction, MoveType]:
        """Main play loop with iterative deepening."""
        start_time = time()
        self.found_trapdoors = board.found_trapdoors.copy()
        self._risk_cache = None

        self.update_trapdoor_beliefs(board, sensor_data, board.chicken_player.get_location())

        moves = board.get_valid_moves()
        if not moves:
            return (Direction.UP, MoveType.PLAIN)

        remaining_time = time_left()
        remaining_turns = board.turns_left_player
        if remaining_turns > 0:
            time_per_move = max(1.0, remaining_time / (remaining_turns + 1))
        else:
            time_per_move = remaining_time * 0.9
        time_limit = min(time_per_move, remaining_time * 0.95)

        best_move = moves[0]
        best_score = float("-inf")
        achieved_depth = 0

        for depth in range(1, self.max_depth + 1):
            if time() - start_time > time_limit * 0.8:
                break

            current_best: Optional[Tuple[Direction, MoveType]] = None
            current_score = float("-inf")
            ordered_moves = self.order_moves(board, moves, depth)

            for move in ordered_moves:
                if time() - start_time > time_limit:
                    break

                dir, move_type = move
                new_board = board.forecast_move(dir, move_type, check_ok=False)
                if new_board is None:
                    continue

                score = self.minimax(
                    new_board,
                    depth - 1,
                    float("-inf"),
                    float("inf"),
                    False,
                    start_time,
                    time_limit - (time() - start_time),
                )

                if score > current_score:
                    current_score = score
                    current_best = move

            if current_best is not None:
                best_move = current_best
                best_score = current_score
                achieved_depth = depth

            if current_score > 5000:  # Clearly winning, stop deepening
                break

        elapsed = time() - start_time
        print(f"Heuristic Move: {best_move}, Score: {best_score:.2f}, Depth: {achieved_depth}, Time: {elapsed:.2f}s")
        return best_move
